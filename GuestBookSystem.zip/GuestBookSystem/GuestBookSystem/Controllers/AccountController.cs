﻿using GuestBookSystem.Models;
using System.Linq;
using System.Web.Mvc;

namespace GuestBookSystem.Controllers
{
    public class AccountController : Controller
    {
        GBSDBContext db = new GBSDBContext();
        // GET: Account
        /*public ActionResult Index()
        {
            return View();
        }
        public ActionResult UserLogin()
        {
            return View();
        }*/

        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Admin admin)
        {
            if (ModelState.IsValid)
            {
                var dbAdminr = db.Admins.Where(a => a.Name == admin.Name && a.Password == admin.Password).FirstOrDefault();
                if (dbAdminr != null)
                {
                    return RedirectToAction("Index");
                }
                ModelState.AddModelError("", "用户名或密码错误");
                return View(admin);
            }
            return View();
        }
    }
}
