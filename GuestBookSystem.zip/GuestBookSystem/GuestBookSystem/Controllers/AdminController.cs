﻿using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using GuestBookSystem.Models;

namespace GuestBookSystem.Controllers
{
    public class AdminController : Controller
    {
        GBSDBContext db = new GBSDBContext();
        // GET: Admin
        public ActionResult Index()
        {
            return View(db.Guestbooks.ToList());
        }

        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        /*public ActionResult Login(User user)
        {
            if (ModelState.IsValid)
            {
                var dbUser = db.Users.Where(a => a.Name == user.Name && a.Password == user.Password).FirstOrDefault();
                if (dbUser != null)
                {
                    FormsAuthentication.SetAuthCookie(user.Name, false);
                    if (dbUser.SRole.ToString() == "管理员")
                    {
                        return RedirectToAction("Index", "Admin");
                    }
                    else if (dbUser.SRole.ToString() == "普通用户")
                    {
                        return RedirectToAction("AllWords", "User");
                    }
                }
            }
            ModelState.AddModelError("", "用户名或密码错误");
            return View(user);
        }*/

        public ActionResult Login(Admin admin)
        {
            /*if (ModelState.IsValid)
            {
                var dbAdminr = db.Admin.Where(a => a.Name == admin.Name && a.Password == admin.Password).FirstOrDefault();
                if (dbAdminr != null)
                {
                    return RedirectToAction("Index");
                }
                ModelState.AddModelError("", "用户名或密码错误");
                return View(admin);
            }*/
            return View();
        }

        public ActionResult Delete(int id)
        {
            var gb = db.Guestbooks.Find(id);
            return View(gb);
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            var gb = db.Guestbooks.Find(id);
            db.Guestbooks.Remove(gb);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
